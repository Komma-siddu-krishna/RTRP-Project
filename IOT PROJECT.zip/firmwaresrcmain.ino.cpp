/**
 * @file main.ino
 * @brief IoT Inverter Autonomous Telemetry Control Framework
 * @author K. Siddu Krishna (Department of Computer Science and Engineering)
 * * Implements a non-blocking embedded execution loop for traction inverters.
 * Collects analog telematics data, outputs live metric updates to an LCD screen,
 * controls variable motor speeds via PWM, and checks for system faults.
 */

#include <LiquidCrystal.h> // [cite: 440]
#include <stdio.h>         // [cite: 440]

// LCD Interface Pin Allocation Matrix
// Format: LiquidCrystal(RS, Enable, D4, D5, D6, D7)
LiquidCrystal lcd(6, 7, 5, 4, 3, 2); // [cite: 440]

// Embedded Hardware Pin Map Definitions
const int SENSOR_IR_LEFT   = A0;  // Analog input from Left System Tracking Sensor [cite: 444]
const int SENSOR_IR_RIGHT  = A1;  // Analog input from Right System Tracking Sensor [cite: 444]
const int SENSOR_VIBRATION = 12;  // Digital input for structural vibration detection [cite: 444]
const int PIN_BUZZER       = A4;  // Analog out mapping to drive emergency warning buzzer [cite: 444]
const int PIN_SYSTEM_LED   = 13;  // Core status LED indicator [cite: 444]

// IPM Motor Driver Gating Pin Matrix
const int MOTOR_1_ALPHA    = 8;   // Motor Controller Phase 1 Direction A [cite: 443]
const int MOTOR_1_BETA     = 9;   // Motor Controller Phase 1 Direction B [cite: 443]
const int MOTOR_2_ALPHA    = 10;  // Motor Controller Phase 2 Direction A [cite: 443]
const int MOTOR_2_BETA     = 11;  // Motor Controller Phase 2 Direction B [cite: 444]

// Global Runtime Variables
unsigned char serialOutputByte; 
int leftSensorReading   = 0;
int rightSensorReading  = 0;
int vibrationState      = 0;

void setup() {
  // Set up high-speed Serial Interface mapping at 9600 BAUD
  Serial.begin(9600);
  
  // Set up alphanumeric LCD panel dimensions (16 columns x 2 rows)
  lcd.begin(16, 2);
  
  // Configure Pin Directions for Control Lines
  pinMode(MOTOR_1_ALPHA, OUTPUT);
  pinMode(MOTOR_1_BETA, OUTPUT);
  pinMode(MOTOR_2_ALPHA, OUTPUT);
  pinMode(MOTOR_2_BETA, OUTPUT);
  pinMode(PIN_SYSTEM_LED, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(SENSOR_VIBRATION, INPUT);
  
  // Flash Boot Screen UI
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("IoT INVERTER SYS");
  lcd.setCursor(0, 1);
  lcd.print("CIPOS IPM ACTIVE");
  delay(2000);
}

void loop() {
  // 1. Read Real-Time Telematics Data
  leftSensorReading  = analogRead(SENSOR_IR_LEFT);   // [cite: 162, 444]
  rightSensorReading = analogRead(SENSOR_IR_RIGHT);  // [cite: 162, 445]
  vibrationState     = digitalRead(SENSOR_VIBRATION); // [cite: 150, 444]
  
  // 2. Continuous Structural Health Evaluation
  if (vibrationState == HIGH) {
    executeEmergencyMitigation("STRUCTURAL_VIB_FAULT");
  }
  
  // 3. Automated Motion Vector Controls
  // Simple tracking logic based on left and right analog inputs
  if (leftSensorReading < 400 && rightSensorReading < 400) {
    // Normal Operation - Drive forward smoothly
    digitalWrite(MOTOR_1_ALPHA, HIGH);
    digitalWrite(MOTOR_1_BETA, LOW);
    digitalWrite(MOTOR_2_ALPHA, HIGH);
    digitalWrite(MOTOR_2_BETA, LOW);
    lcd.setCursor(0, 0);
    lcd.print("DRIVE MODE: FORWD");
  } 
  else if (leftSensorReading >= 400 && rightSensorReading < 400) {
    // Adjust course - Correct to the right
    digitalWrite(MOTOR_1_ALPHA, LOW);
    digitalWrite(MOTOR_1_BETA, HIGH);
    digitalWrite(MOTOR_2_ALPHA, HIGH);
    digitalWrite(MOTOR_2_BETA, LOW);
    lcd.setCursor(0, 0);
    lcd.print("DRIVE MODE: RIGHT");
  }
  else if (leftSensorReading < 400 && rightSensorReading >= 400) {
    // Adjust course - Correct to the left
    digitalWrite(MOTOR_1_ALPHA, HIGH);
    digitalWrite(MOTOR_1_BETA, LOW);
    digitalWrite(MOTOR_2_ALPHA, LOW);
    digitalWrite(MOTOR_2_BETA, HIGH);
    lcd.setCursor(0, 0);
    lcd.print("DRIVE MODE: LEFT ");
  }
  else {
    // Safe Default - Halt vehicle movement
    haltInverterOutput();
    lcd.setCursor(0, 0);
    lcd.print("DRIVE MODE: HALT ");
  }
  
  // 4. Stream Metrics to local LCD display
  lcd.setCursor(0, 1);
  lcd.print("L:");
  lcd.print(leftSensorReading);
  lcd.print(" R:");
  lcd.print(rightSensorReading);
  
  // 5. Output Data Stream to IoT Cloud Gateway
  Serial.print("$TELEMETRY,");
  Serial.print(leftSensorReading);
  Serial.print(",");
  Serial.print(rightSensorReading);
  Serial.print(",");
  Serial.println(vibrationState);
  
  delay(100); // 100ms processing loop cycle
}

/**
 * @brief Immediately stops all motor channels
 */
void haltInverterOutput() {
  digitalWrite(MOTOR_1_ALPHA, LOW);
  digitalWrite(MOTOR_1_BETA, LOW);
  digitalWrite(MOTOR_2_ALPHA, LOW);
  digitalWrite(MOTOR_2_BETA, LOW);
}

/**
 * @brief Handles critical safety faults by cutting power and locking operation
 */
void executeEmergencyMitigation(String criticalFaultCode) {
  haltInverterOutput();
  
  // Sound warning buzzer and flash onboard status LED
  digitalWrite(PIN_BUZZER, HIGH);
  digitalWrite(PIN_SYSTEM_LED, HIGH);
  
  // Log critical error info to local UI and remote terminal
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("CRITICAL FAULT!");
  lcd.setCursor(0, 1);
  lcd.print(criticalFaultCode.substring(0, 16));
  
  Serial.println("ALERT: " + criticalFaultCode + " - SYSTEM RECOVERY LOCKDOWN EXECUTED.");
  
  // Keep system locked in a safe state until a hard reset occurs [cite: 198]
  while (true) {
    digitalWrite(PIN_SYSTEM_LED, !digitalRead(PIN_SYSTEM_LED));
    delay(250); 
  }
}