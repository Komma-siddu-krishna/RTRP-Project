# Chapter 5: Hardware Specifications

## 5.1 Central Microcontroller Core (ATmega328P)
[cite_start]The system core relies on an ATmega328P 8-bit AVR microcontroller operating on a Harvard memory architecture to separate program instructions from active runtime memory[cite: 144].