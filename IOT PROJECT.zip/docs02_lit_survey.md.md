# Chapter 2: Literature Survey

[cite_start]This section outlines the engineering methodologies and diagnostic frameworks evaluated from five distinct 2023 IEEE academic papers to build the technical foundation of the repository[cite: 38, 59].

### Paper 1: IoT-Based Inverter System for Autonomous Electric Vehicle Drive
* [cite_start]**Authors:** A. Sharma, R. Kumar, and P. Singh (2023, IEEE) [cite: 59]
* [cite_start]**Core Contribution:** Investigates the baseline coupling of remote smart telemetry arrays with traction power systems[cite: 59, 60]. [cite_start]Demonstrates that shifting telemetry loops onto CIPOS IPM power electronics drastically reduces heat losses and establishes a stable edge tracking network for dynamic, un-crewed driving tasks[cite: 61, 62].

### Paper 2: Smart IoT-Controlled Inverter for Electric Vehicle Power Management
* [cite_start]**Authors:** M. Patel, S. Verma, and L. Gupta (2023, IEEE) [cite: 67]
* [cite_start]**Core Contribution:** Focuses on power conversion parameters and dynamic range optimization[cite: 67, 68]. [cite_start]Proves that continuously feeding line output trends up to cloud-analytics dashboards allows for real-time adjustments that directly lengthen battery runtimes and improve vehicle driving range[cite: 70, 73].

### Paper 3: IoT-Enabled Predictive Maintenance for CIPOS IPM-Based EV Inverter
* [cite_start]**Authors:** T. Banerjee, K. Rao, and N. Mishra (2023, IEEE) [cite: 74]
* [cite_start]**Core Contribution:** Evaluates machine learning algorithms trained to monitor real-time sensor streams from CIPOS modules[cite: 74, 75, 76]. [cite_start]Relies on detecting subtle signal variations early to trigger preventive maintenance schedules, avoiding sudden on-road breakdowns and reducing overall vehicle maintenance costs[cite: 77, 81].

### Paper 4: IoT-Based Remote Monitoring of Inverter Performance in Autonomous EVs
* [cite_start]**Authors:** D. Zhang, H. Wang, and Y. Chen (2023, IEEE) [cite: 82]
* [cite_start]**Core Contribution:** Outlines an automated telemetry structure that streams live system health logs directly to a central cloud architecture[cite: 83]. [cite_start]This framework replaces traditional manual checkups with continuous cloud diagnostics, supporting remote troubleshooting and automated fault flagging[cite: 84, 87, 88].

### Paper 5: AI-Driven IoT Framework for Optimizing CIPOS IPM-Based Inverter Efficiency
* [cite_start]**Authors:** R. Nair, S. Das, and A. Srinivasan (2023, IEEE) [cite: 90]
* [cite_start]**Core Contribution:** Introduces predictive intelligence layers that dynamically tune inverter gating profiles in real time[cite: 91, 96]. [cite_start]This method mitigates extreme heat generation, addresses battery consumption challenges, and ensures high energy conversion efficiency under heavy electrical loads[cite: 93, 97].